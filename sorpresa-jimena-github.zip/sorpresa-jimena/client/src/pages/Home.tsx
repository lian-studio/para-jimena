import { useEffect, useState } from "react";
import { Heart, RotateCcw, Sparkles } from "lucide-react";

const MESSAGE =
  "Este ramito de flores amarillas es para ti, Jimena. 🌻💛 Por si nadie te las dio o simplemente nadie se acordó, quise tener este pequeño detalle contigo. Espero de corazón que te guste y que te saque una bonita sonrisa.";

const petals = Array.from({ length: 18 }, (_, index) => ({
  left: `${(index * 17 + 5) % 100}%`,
  delay: `${(index % 8) * 0.55}s`,
  duration: `${7 + (index % 5) * 1.2}s`,
  rotate: `${index * 31}deg`,
  size: `${7 + (index % 4) * 2}px`,
}));

const sparkles = Array.from({ length: 12 }, (_, index) => ({
  left: `${12 + ((index * 29) % 76)}%`,
  top: `${10 + ((index * 37) % 76)}%`,
  delay: `${(index % 6) * 0.4}s`,
  size: `${5 + (index % 3) * 3}px`,
}));

function Envelope() {
  return (
    <div className="envelope-scene" aria-label="Una carta cerrada para Jimena" role="img">
      <div className="envelope-shadow" />
      <div className="envelope">
        <div className="envelope-back" />
        <div className="envelope-letter">
          <span className="letter-kicker">Una pequeña sorpresa</span>
          <strong>Para Jimena</strong>
          <span className="letter-flower">🌻</span>
        </div>
        <div className="envelope-flap" />
        <div className="envelope-front" />
        <div className="envelope-seal">💛</div>
      </div>
    </div>
  );
}

function GiftPhoto() {
  return (
    <figure className="gift-photo-frame">
      <div className="gift-photo-halo" />
      <div className="gift-photo-card">
        <img
          className="gift-photo"
          src="/assets/oso-flores-amarillas.png"
          alt="Oso de peluche junto a un ramo de rosas amarillas"
        />
        <div className="gift-photo-shine" />
      </div>
      <figcaption className="gift-caption"><span />un regalo lleno de cariño<span /></figcaption>
    </figure>
  );
}

export default function Home() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    document.title = "Una sorpresa para Jimena · 🌻";
  }, []);

  const replay = () => {
    setIsOpen(false);
    window.setTimeout(() => setIsOpen(true), 90);
  };

  return (
    <main className={`romantic-page ${isOpen ? "is-open" : ""}`}>
      <div className="ambient-glow ambient-glow-one" />
      <div className="ambient-glow ambient-glow-two" />
      <div className="grain" />
      <div className="sparkles" aria-hidden="true">
        {sparkles.map((sparkle, index) => (
          <i
            key={index}
            className="sparkle"
            style={{ left: sparkle.left, top: sparkle.top, animationDelay: sparkle.delay, width: sparkle.size, height: sparkle.size }}
          />
        ))}
      </div>
      <div className="petal-field" aria-hidden="true">
        {petals.map((petal, index) => (
          <i
            key={index}
            className="falling-petal"
            style={{
              left: petal.left,
              animationDelay: petal.delay,
              animationDuration: petal.duration,
              transform: `rotate(${petal.rotate})`,
              width: petal.size,
              height: `calc(${petal.size} * 1.65)`,
            }}
          />
        ))}
      </div>

      <header className="topbar">
        <div className="brand-mark" aria-label="Un detalle para Jimena">
          <span className="brand-flower">✽</span>
          <span>un detalle para ti</span>
        </div>
        <div className="topbar-note">21 · 09 · 26</div>
      </header>

      <section className="experience-shell" aria-live="polite">
        <div className="eyebrow"><span />una sorpresa en forma de carta<span /></div>

        {!isOpen ? (
          <div className="opening-panel letter-opening-panel">
            <div className="opening-copy">
              <p className="mini-kicker">Para abrir con cariño</p>
              <h1>Hay algo <em>especial</em> para ti...</h1>
              <Envelope />
              <button className="primary-button" onClick={() => setIsOpen(true)} type="button">
                Abrir carta <span>💛</span>
              </button>
              <p className="opening-hint"><Sparkles size={14} /> Preparado especialmente para Jimena</p>
            </div>
          </div>
        ) : (
          <div className="revealed-layout">
            <div className="bouquet-column">
              <div className="reveal-label">para ti, Jimena <Heart size={14} fill="currentColor" /></div>
              <GiftPhoto />
            </div>
            <div className="letter-column">
              <p className="mini-kicker">Una nota para ti</p>
              <h1>Jimena <span>💛</span></h1>
              <div className="gold-rule"><span /><i>✦</i><span /></div>
              <p className="message">{MESSAGE}</p>
              <div className="signature">Con cariño, <strong>alguien que pensó en ti</strong></div>
              <button className="replay-button" onClick={replay} type="button">
                <RotateCcw size={14} /> Ver la carta de nuevo
              </button>
            </div>
          </div>
        )}
      </section>

      <footer className="footer-note">
        <span>hecho con luz, flores y un poquito de magia</span>
        <span className="footer-heart">♥</span>
      </footer>
    </main>
  );
}

export { MESSAGE };
